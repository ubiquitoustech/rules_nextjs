function hello(name) {
  alert('Hello, ' + name);
}
hello('New user');
