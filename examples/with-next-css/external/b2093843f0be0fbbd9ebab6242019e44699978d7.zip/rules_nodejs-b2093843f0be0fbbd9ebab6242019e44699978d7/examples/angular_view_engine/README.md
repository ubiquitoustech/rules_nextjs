# Example Angular application using Bazel

**This is experimental, as part of Angular Labs! There may be breaking changes.**

There are a few ways to use Angular with Bazel. See https://bazelbuild.github.io/rules_nodejs/examples#angular for an overview of all the options.

This is a ViewEngine version of the Angular example at /examples/angular, based on the Google-internal toolchain.
