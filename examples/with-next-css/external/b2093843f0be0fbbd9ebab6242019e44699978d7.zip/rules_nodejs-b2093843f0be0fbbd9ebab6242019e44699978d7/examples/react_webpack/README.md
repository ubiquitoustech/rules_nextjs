This example shows how to use Webpack to build and serve a React app with Bazel.

We use the minimal webpack loaders, because Bazel takes care of things like Sass and TypeScript compilation before calling webpack.
