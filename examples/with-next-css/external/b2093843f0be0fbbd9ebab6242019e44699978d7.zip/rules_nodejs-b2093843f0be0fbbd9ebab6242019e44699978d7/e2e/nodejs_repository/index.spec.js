// Empty test file. The test target primarily exists to ensure
// that Bazel targets are not misconfigured. See BUILD.bazel.