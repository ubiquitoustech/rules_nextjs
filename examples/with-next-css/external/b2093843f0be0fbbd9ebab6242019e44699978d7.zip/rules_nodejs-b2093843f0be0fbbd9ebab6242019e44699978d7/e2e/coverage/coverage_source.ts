export function isString(input: string) {
  if (typeof input === 'string') {
    return true;
  } else {
    return false;
  }
}
