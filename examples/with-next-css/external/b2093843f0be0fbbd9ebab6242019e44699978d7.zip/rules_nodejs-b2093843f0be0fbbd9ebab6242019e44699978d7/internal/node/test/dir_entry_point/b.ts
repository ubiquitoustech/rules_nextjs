if (require.main === module) {
  process.stdout.write('running entry point B')
}
