function addD(str) {
  return `${str}_d`;
}

exports.addD = addD;