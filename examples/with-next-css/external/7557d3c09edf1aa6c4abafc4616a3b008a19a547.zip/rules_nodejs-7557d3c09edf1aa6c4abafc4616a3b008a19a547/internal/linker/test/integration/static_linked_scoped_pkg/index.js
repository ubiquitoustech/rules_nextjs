function addE(str) {
  return `${str}_e`;
}

exports.addE = addE;