import { NgModule } from '@angular/core';
import { FrontendLibComponent } from './frontend-lib.component';



@NgModule({
  declarations: [FrontendLibComponent],
  imports: [
  ],
  exports: [FrontendLibComponent]
})
export class FrontendLibModule { }
