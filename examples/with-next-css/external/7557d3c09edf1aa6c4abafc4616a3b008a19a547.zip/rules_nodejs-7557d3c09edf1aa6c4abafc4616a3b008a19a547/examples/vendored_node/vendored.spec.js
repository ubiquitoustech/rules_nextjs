describe('vendored node', () => {
  it('version should be 15.0.1', () => {
    expect(process.version).toBe('v15.0.1');
  });
});
