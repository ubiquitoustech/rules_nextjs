export function hello(): string {
  return 'Hello Webapp';
}
