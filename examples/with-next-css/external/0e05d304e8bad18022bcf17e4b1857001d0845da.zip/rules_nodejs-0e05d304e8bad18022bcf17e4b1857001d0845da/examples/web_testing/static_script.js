// Some test data that is loaded dynamically from the test
window.someGlobal = 'someGlobalValue';
