/// <amd-module name="examples_webtesting/decrement"/>
export function decrement(n: number) {
  return n - 1;
}
