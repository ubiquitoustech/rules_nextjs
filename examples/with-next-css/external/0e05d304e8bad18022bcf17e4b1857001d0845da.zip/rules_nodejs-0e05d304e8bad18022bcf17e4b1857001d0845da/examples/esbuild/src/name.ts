export const NAME = 'rules_nodejs';
