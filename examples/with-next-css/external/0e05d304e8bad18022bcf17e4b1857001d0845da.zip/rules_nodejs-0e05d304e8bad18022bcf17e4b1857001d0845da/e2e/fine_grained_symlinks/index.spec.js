// Assert that there isn't an exception here
require('webpack');
