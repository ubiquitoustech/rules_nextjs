function addC(str) {
  return `${str}_c`;
}

exports.addC = addC;