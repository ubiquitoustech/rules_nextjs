function addB(str) {
  return `${str}_b`;
}

exports.addB = addB;