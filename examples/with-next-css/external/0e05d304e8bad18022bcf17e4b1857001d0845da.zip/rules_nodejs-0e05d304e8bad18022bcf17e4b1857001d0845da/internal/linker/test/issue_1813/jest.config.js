module.exports = {
  haste: {
    enableSymlinks: true,
  },
  testEnvironment: 'node',
  testMatch: ['**/*.test.js'],
};
