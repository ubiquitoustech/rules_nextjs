function addT(str) {
  return `${str}_t`;
}

exports.addT = addT;