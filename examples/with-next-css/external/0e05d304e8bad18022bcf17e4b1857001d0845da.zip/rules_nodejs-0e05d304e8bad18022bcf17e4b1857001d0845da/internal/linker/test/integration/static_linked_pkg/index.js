function addA(str) {
  return `${str}_a`;
}

exports.addA = addA;