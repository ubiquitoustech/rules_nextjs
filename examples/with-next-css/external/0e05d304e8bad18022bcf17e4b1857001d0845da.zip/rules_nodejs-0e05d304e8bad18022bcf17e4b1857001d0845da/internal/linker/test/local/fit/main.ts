export const fit: string = 'fit';
