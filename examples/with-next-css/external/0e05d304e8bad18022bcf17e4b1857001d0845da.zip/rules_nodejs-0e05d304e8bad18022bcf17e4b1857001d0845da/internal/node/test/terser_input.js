class A {
  doThing() {
    console.error('thing');
  }
}
