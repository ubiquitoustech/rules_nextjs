console.log('Awesome APP is launched!');
