var foo_1 = require('./some');
exports.a = foo_1.a;