import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-frontend-lib',
  template: `
    <p>
      frontend-lib works!
    </p>
  `,
  styles: []
})
export class FrontendLibComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
