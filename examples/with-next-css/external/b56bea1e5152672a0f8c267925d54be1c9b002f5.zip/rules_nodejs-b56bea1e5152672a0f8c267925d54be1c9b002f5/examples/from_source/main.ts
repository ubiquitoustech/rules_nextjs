console.log('rules_nodejs from source example');
