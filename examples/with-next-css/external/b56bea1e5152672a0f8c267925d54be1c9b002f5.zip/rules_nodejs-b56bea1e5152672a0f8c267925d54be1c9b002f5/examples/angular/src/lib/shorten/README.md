# A simple example TS-only library

This shows how a TypeScript library looks in a Bazel monorepo.
