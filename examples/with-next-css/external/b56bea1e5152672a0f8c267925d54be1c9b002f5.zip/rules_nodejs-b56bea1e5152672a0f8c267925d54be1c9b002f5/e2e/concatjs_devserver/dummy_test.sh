echo "Just a dummy test so that we have a test target for //... on certain bazelci platforms with bazel_integration_test"
exit 0