console.log('test postinstall step');
