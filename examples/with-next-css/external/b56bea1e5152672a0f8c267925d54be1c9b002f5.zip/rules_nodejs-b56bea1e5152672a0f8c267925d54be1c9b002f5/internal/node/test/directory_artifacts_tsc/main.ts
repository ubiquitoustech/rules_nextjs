export const a: string = require('./src/some').a;
