if (!global.bootstrapped) {
  console.error('should run bootstrap script first');
  process.exitCode = 1;
}
