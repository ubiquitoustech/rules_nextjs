global.bootstrapped = true;
// Verify that we can require npm packages in a bootstrap script
const tmp = require('tmp');
