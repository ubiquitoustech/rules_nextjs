console.log('ExternalNpmPackageInfo with no path works!');
