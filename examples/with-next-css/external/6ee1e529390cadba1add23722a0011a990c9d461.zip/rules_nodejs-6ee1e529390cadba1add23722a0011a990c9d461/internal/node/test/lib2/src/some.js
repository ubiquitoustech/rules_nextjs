exports.a = 'lib2 content';
