global.bootstrapped = global.bootstrapped ? global.bootstrapped + 1 : 1;
global.last_bootstrap = 'bootstrap2';