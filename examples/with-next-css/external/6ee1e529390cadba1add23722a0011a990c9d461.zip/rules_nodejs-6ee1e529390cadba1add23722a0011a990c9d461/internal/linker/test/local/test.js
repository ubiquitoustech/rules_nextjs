describe('linker', () => {
  it('should work when job run with "local" tag', () => {
    const fit = require('fit');
    expect(fit.fit).toBe('fit');
  });
});
