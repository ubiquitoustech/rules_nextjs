echo "Just some program that is never executed and just used for its static transitive runfiles module mappings"
