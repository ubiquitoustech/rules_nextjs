module.exports = {
  bar: 'bar',
}
