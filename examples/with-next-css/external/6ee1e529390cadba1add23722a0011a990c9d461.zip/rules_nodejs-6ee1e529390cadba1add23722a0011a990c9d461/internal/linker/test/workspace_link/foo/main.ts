export const foo: string = 'foo';
