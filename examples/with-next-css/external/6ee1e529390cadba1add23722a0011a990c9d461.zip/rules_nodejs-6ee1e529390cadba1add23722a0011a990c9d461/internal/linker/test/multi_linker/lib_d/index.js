const other = require('./other')

module.exports = other;
