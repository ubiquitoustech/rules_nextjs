# Manual generation of index.js

Incase the API of generate_build_files.ts changes to the point where you
can't updated the generated index.js with bazel, run `internal/npm_install/manual_update.sh`.
