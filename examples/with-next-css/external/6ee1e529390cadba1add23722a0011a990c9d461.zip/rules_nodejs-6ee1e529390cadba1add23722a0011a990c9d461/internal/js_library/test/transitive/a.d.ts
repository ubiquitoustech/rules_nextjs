export declare const a: string;
