function foo(str) {
  return `foo_${str}`;
}

exports.foo = foo;