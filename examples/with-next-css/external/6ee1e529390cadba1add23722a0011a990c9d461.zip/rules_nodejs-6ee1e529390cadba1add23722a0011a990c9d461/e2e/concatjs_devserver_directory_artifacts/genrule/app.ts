/// <amd-module name="concatjs_devserver_directory_artifacts/genrule/app"/>

const el: HTMLDivElement = document.createElement('div');
el.innerText = 'Hello, TypeScript';
el.className = 'ts1';
document.body.appendChild(el);
