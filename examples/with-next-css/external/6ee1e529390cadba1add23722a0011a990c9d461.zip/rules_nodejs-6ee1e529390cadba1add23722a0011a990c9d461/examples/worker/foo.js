// This is an arbitrary file used as an input to the worker action
// Any time this file is changed, the action will need to re-run
export const num = 0;
