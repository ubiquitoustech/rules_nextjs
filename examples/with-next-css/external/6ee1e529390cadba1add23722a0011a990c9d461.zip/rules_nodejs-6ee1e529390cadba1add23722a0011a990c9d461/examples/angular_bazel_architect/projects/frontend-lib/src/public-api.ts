/*
 * Public API Surface of frontend-lib
 */

export * from './lib/frontend-lib.service';
export * from './lib/frontend-lib.component';
export * from './lib/frontend-lib.module';
