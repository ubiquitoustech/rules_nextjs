import indexfile from 'lib';

test('it should work', () => {
  expect(indexfile).toBe('test');
});
