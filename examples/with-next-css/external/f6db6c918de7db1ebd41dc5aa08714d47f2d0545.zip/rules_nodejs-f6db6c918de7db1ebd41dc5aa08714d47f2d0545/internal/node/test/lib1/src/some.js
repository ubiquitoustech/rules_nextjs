exports.a = 'lib1 content';
